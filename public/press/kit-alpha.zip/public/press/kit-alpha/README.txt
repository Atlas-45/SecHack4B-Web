GLASS KEY Photo Archive - README (Kit A)

Included files:
- press-kit.txt
- credits.txt
- image-list.txt

Use for editorial/press purposes only.
