GLASS KEY Photo Archive - README (Kit B)

Included files:
- press-kit.txt
- credits.txt
- image-list.txt

Use for editorial/press purposes only.
