GLASS KEY Photo Archive - README (Kit C)

Included files:
- press-kit.txt
- credits.txt
- image-list.txt

Note: Directory tree is stored at /archive?path=public/press/.tree
